--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE quan_ly_nha_van_hoa;
--
-- Name: quan_ly_nha_van_hoa; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE quan_ly_nha_van_hoa WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE quan_ly_nha_van_hoa OWNER TO postgres;

\connect quan_ly_nha_van_hoa

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: deleteditem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deleteditem (
    delete_id integer NOT NULL,
    item_id integer NOT NULL,
    reason character varying(255) NOT NULL,
    item_number integer NOT NULL,
    date time with time zone NOT NULL
);


ALTER TABLE public.deleteditem OWNER TO postgres;

--
-- Name: deleteditem_delete_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deleteditem_delete_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deleteditem_delete_id_seq OWNER TO postgres;

--
-- Name: deleteditem_delete_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.deleteditem_delete_id_seq OWNED BY public.deleteditem.delete_id;


--
-- Name: deleteditem_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deleteditem_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deleteditem_item_id_seq OWNER TO postgres;

--
-- Name: deleteditem_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.deleteditem_item_id_seq OWNED BY public.deleteditem.item_id;


--
-- Name: infraregistered; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.infraregistered (
    infra_id integer NOT NULL,
    user_id integer NOT NULL,
    event_no integer NOT NULL
);


ALTER TABLE public.infraregistered OWNER TO postgres;

--
-- Name: infrastructure; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.infrastructure (
    infra_id integer NOT NULL,
    infra_name character varying(255) NOT NULL,
    reason character varying(255)
);


ALTER TABLE public.infrastructure OWNER TO postgres;

--
-- Name: infrastructure_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.infrastructure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.infrastructure_id_seq OWNER TO postgres;

--
-- Name: infrastructure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.infrastructure_id_seq OWNED BY public.infrastructure.infra_id;


--
-- Name: item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item (
    item_id integer NOT NULL,
    item_name character varying(255) NOT NULL,
    item_quantity integer NOT NULL
);


ALTER TABLE public.item OWNER TO postgres;

--
-- Name: item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_id_seq OWNER TO postgres;

--
-- Name: item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_id_seq OWNED BY public.item.item_id;


--
-- Name: itemregistered; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.itemregistered (
    item_id integer NOT NULL,
    user_id integer NOT NULL,
    event_no integer NOT NULL,
    item_number integer NOT NULL
);


ALTER TABLE public.itemregistered OWNER TO postgres;

--
-- Name: money; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.money (
    money_id integer NOT NULL,
    item_id integer NOT NULL,
    item_number integer NOT NULL,
    date date NOT NULL,
    reason character varying(255)
);


ALTER TABLE public.money OWNER TO postgres;

--
-- Name: money_money_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.money_money_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.money_money_id_seq OWNER TO postgres;

--
-- Name: money_money_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.money_money_id_seq OWNED BY public.money.money_id;


--
-- Name: registers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registers (
    user_id integer NOT NULL,
    user_name character varying(255) NOT NULL,
    user_address character varying(255) NOT NULL,
    user_phone character varying(255) NOT NULL,
    fee_register integer NOT NULL,
    cccd character varying(255) NOT NULL
);


ALTER TABLE public.registers OWNER TO postgres;

--
-- Name: registers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.registers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.registers_id_seq OWNER TO postgres;

--
-- Name: registers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.registers_id_seq OWNED BY public.registers.user_id;


--
-- Name: schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule (
    event_no integer NOT NULL,
    time_start timestamp with time zone NOT NULL,
    time_end timestamp with time zone NOT NULL,
    real_time_end timestamp with time zone
);


ALTER TABLE public.schedule OWNER TO postgres;

--
-- Name: schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schedule_id_seq OWNER TO postgres;

--
-- Name: schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.schedule_id_seq OWNED BY public.schedule.event_no;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100),
    passwd character varying(100)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: deleteditem delete_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deleteditem ALTER COLUMN delete_id SET DEFAULT nextval('public.deleteditem_delete_id_seq'::regclass);


--
-- Name: deleteditem item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deleteditem ALTER COLUMN item_id SET DEFAULT nextval('public.deleteditem_item_id_seq'::regclass);


--
-- Name: infrastructure infra_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.infrastructure ALTER COLUMN infra_id SET DEFAULT nextval('public.infrastructure_id_seq'::regclass);


--
-- Name: item item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item ALTER COLUMN item_id SET DEFAULT nextval('public.item_id_seq'::regclass);


--
-- Name: money money_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.money ALTER COLUMN money_id SET DEFAULT nextval('public.money_money_id_seq'::regclass);


--
-- Name: registers user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registers ALTER COLUMN user_id SET DEFAULT nextval('public.registers_id_seq'::regclass);


--
-- Name: schedule event_no; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule ALTER COLUMN event_no SET DEFAULT nextval('public.schedule_id_seq'::regclass);


--
-- Data for Name: deleteditem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deleteditem (delete_id, item_id, reason, item_number, date) FROM stdin;
\.
COPY public.deleteditem (delete_id, item_id, reason, item_number, date) FROM '$$PATH$$/3374.dat';

--
-- Data for Name: infraregistered; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.infraregistered (infra_id, user_id, event_no) FROM stdin;
\.
COPY public.infraregistered (infra_id, user_id, event_no) FROM '$$PATH$$/3377.dat';

--
-- Data for Name: infrastructure; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.infrastructure (infra_id, infra_name, reason) FROM stdin;
\.
COPY public.infrastructure (infra_id, infra_name, reason) FROM '$$PATH$$/3378.dat';

--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item (item_id, item_name, item_quantity) FROM stdin;
\.
COPY public.item (item_id, item_name, item_quantity) FROM '$$PATH$$/3380.dat';

--
-- Data for Name: itemregistered; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.itemregistered (item_id, user_id, event_no, item_number) FROM stdin;
\.
COPY public.itemregistered (item_id, user_id, event_no, item_number) FROM '$$PATH$$/3382.dat';

--
-- Data for Name: money; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.money (money_id, item_id, item_number, date, reason) FROM stdin;
\.
COPY public.money (money_id, item_id, item_number, date, reason) FROM '$$PATH$$/3383.dat';

--
-- Data for Name: registers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registers (user_id, user_name, user_address, user_phone, fee_register, cccd) FROM stdin;
\.
COPY public.registers (user_id, user_name, user_address, user_phone, fee_register, cccd) FROM '$$PATH$$/3385.dat';

--
-- Data for Name: schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule (event_no, time_start, time_end, real_time_end) FROM stdin;
\.
COPY public.schedule (event_no, time_start, time_end, real_time_end) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, passwd) FROM stdin;
\.
COPY public.users (id, username, passwd) FROM '$$PATH$$/3389.dat';

--
-- Name: deleteditem_delete_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deleteditem_delete_id_seq', 1, false);


--
-- Name: deleteditem_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deleteditem_item_id_seq', 1, false);


--
-- Name: infrastructure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.infrastructure_id_seq', 10, true);


--
-- Name: item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_id_seq', 9, true);


--
-- Name: money_money_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.money_money_id_seq', 9, true);


--
-- Name: registers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.registers_id_seq', 4, true);


--
-- Name: schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.schedule_id_seq', 5, true);


--
-- Name: deleteditem deleteditem_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deleteditem
    ADD CONSTRAINT deleteditem_pk PRIMARY KEY (delete_id);


--
-- Name: infraregistered infraregistered_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.infraregistered
    ADD CONSTRAINT infraregistered_pk PRIMARY KEY (infra_id, user_id, event_no);


--
-- Name: infrastructure infrastructure_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.infrastructure
    ADD CONSTRAINT infrastructure_pk PRIMARY KEY (infra_id);


--
-- Name: item item_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item
    ADD CONSTRAINT item_pk PRIMARY KEY (item_id);


--
-- Name: itemregistered itemregistered_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itemregistered
    ADD CONSTRAINT itemregistered_pk PRIMARY KEY (item_id, user_id, event_no);


--
-- Name: money money_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.money
    ADD CONSTRAINT money_pk PRIMARY KEY (money_id);


--
-- Name: registers registers_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registers
    ADD CONSTRAINT registers_pk PRIMARY KEY (user_id);


--
-- Name: schedule schedule_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_pk PRIMARY KEY (event_no);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: deleteditem deleteditem_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deleteditem
    ADD CONSTRAINT deleteditem_fk0 FOREIGN KEY (item_id) REFERENCES public.item(item_id);


--
-- Name: infraregistered infraregistered_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.infraregistered
    ADD CONSTRAINT infraregistered_fk0 FOREIGN KEY (infra_id) REFERENCES public.infrastructure(infra_id);


--
-- Name: infraregistered infraregistered_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.infraregistered
    ADD CONSTRAINT infraregistered_fk1 FOREIGN KEY (user_id) REFERENCES public.registers(user_id);


--
-- Name: infraregistered infraregistered_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.infraregistered
    ADD CONSTRAINT infraregistered_fk2 FOREIGN KEY (event_no) REFERENCES public.schedule(event_no);


--
-- Name: itemregistered itemregistered_fk0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itemregistered
    ADD CONSTRAINT itemregistered_fk0 FOREIGN KEY (item_id) REFERENCES public.item(item_id);


--
-- Name: itemregistered itemregistered_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itemregistered
    ADD CONSTRAINT itemregistered_fk1 FOREIGN KEY (user_id) REFERENCES public.registers(user_id);


--
-- Name: itemregistered itemregistered_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.itemregistered
    ADD CONSTRAINT itemregistered_fk2 FOREIGN KEY (event_no) REFERENCES public.schedule(event_no);


--
-- Name: money money_fk1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.money
    ADD CONSTRAINT money_fk1 FOREIGN KEY (item_id) REFERENCES public.item(item_id);


--
-- PostgreSQL database dump complete
--

